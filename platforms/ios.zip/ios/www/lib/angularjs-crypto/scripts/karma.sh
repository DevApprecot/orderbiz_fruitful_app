#!/bin/sh
./node_modules/.bin/karma start karma/karma.conf-$1.js --single-run